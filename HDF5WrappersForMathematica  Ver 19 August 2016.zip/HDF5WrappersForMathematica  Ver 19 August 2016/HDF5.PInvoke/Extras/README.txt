14 August 2016

* ILSpy_Master_2.4.0.1963_Binaries is useful for examing the contents of "HDF.PInvoke.dll".

* h4h5tools-2.2.2 is useful for converting H4 files to H5 files.
