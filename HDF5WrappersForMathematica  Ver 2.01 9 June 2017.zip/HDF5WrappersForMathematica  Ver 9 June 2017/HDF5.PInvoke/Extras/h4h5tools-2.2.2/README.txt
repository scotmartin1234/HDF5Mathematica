H4H5 Tools release compiled using Visual Studio 2010 on Windows 7 x64.

This directory includes the static binary distribution of h4toh5 library and 
conversion tools built with HDF 4.2.9 and HDF5 1.8.11 libraries.

The contents of this directory are:

        COPYING                - Copyright notice
        README.txt             - This file
        H4TOH5-2.2.2-win64.exe - Install program with h4toh5 library and tools

Please send questions, comments, and suggestions to:

        help@hdfgroup.org


