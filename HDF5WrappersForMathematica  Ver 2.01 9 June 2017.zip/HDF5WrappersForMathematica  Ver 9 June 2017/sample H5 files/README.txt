Accessed, 30 July 2016

https://www.hdfgroup.org/ftp/HDF5/examples/files/exbyapi/

https://www.hdfgroup.org/ftp/HDF5/examples/misc-examples/sample-programs/index.html

